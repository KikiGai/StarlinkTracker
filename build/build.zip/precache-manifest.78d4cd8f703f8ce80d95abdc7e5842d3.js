self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "16917041784a23f4570e1810ca8def0e",
    "url": "/index.html"
  },
  {
    "revision": "24c548789df74570e08b",
    "url": "/static/css/2.1c88de4d.chunk.css"
  },
  {
    "revision": "498fce0218b24251c61e",
    "url": "/static/css/main.fecb0533.chunk.css"
  },
  {
    "revision": "24c548789df74570e08b",
    "url": "/static/js/2.d5df621c.chunk.js"
  },
  {
    "revision": "6aa1b83644e20ee042c69d6872460479",
    "url": "/static/js/2.d5df621c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "45bf22bf56e5716f3477",
    "url": "/static/js/3.50d3c398.chunk.js"
  },
  {
    "revision": "498fce0218b24251c61e",
    "url": "/static/js/main.18f4ca37.chunk.js"
  },
  {
    "revision": "0900aa5c5f9031090a7d",
    "url": "/static/js/runtime-main.f10c722e.js"
  },
  {
    "revision": "141ccf71d7c4a352123d5d70c62a6d96",
    "url": "/static/media/satellite.141ccf71.svg"
  },
  {
    "revision": "b9d88695513de324252dd420ed3b52d4",
    "url": "/static/media/starlink_logo.b9d88695.svg"
  }
]);